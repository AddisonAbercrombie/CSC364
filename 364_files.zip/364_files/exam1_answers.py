myName = 'lastname, firstname'
myTechID = 'yourStudentID'
myTechEmail = 'xxxx@latech.edu'

mtQ1 = """
# r6 = r5 - 7 * r3 + 800
# r5, r3 are integer inputs that will be passed to this routine
# r6 is the output to be returned

Set(r2, 7)

# mul ============
# r4 = r2 * r3
# init var
Set(r0, 0)
Set(r4, 0)

# fix sign
# if r2 < 0
# goto >endif if not
Addi(r10, pc, 4)
Movep(pc, r10, r2)
  Sub(r2, r0, r2)
  Sub(r3, r0, r3)
# >endif

Addi(r10, pc, 6) # >endwhile
# >while r2 > 0
# goto >endwhile if not
Sub(r9, r0, r2)
Movep(pc, r10, r9)
  # whilepart
  Add(r4, r4, r3)
  # update var
  Subi(r2, r2, 1)
  # goto >while
  Subi(pc, pc, 4)
# >endwhile
# =================

Sub(r6, r5, r4)
Set(r7, 800%256)
Seth(r7, 800//256)
Add(r6, r6, r7)

"""

mtQ2 = """
# r6 = rotate_right(r2)
# r2 is integer input
# r6 is the output that is bitwise rotate right once of r2
# HINT: rotate left 15 times results in rotate right once

Set(r3, 0) # counter 0..14
#>while r3 < 15
# goto >endwhile if r3 >= 15
Subi(r9, r3, 15)
Addi(r10, pc, ?endwhile)
Movep(pc, r10, r9)
  # r2 rotate left once
  Set(r0,0)
  Set(r1,1)
  Moven(r0,r1,r2)
  Add(r2,r2,r2)
  Or(r2,r2,r0)
  # update var
  Addi(r3,r3,1)
  # goto >while
  Subi(pc, pc, ?while)
#>endwhile
Move(r6, r2)
"""

mtQ3 = """
# r4 = abs(r2) // abs(r3)
# r5 = abs(r2) % abs(r3)
# r2, r3 are integer inputs that can be positve, nagative, or zero. 
# r4, r5 are outputs where the returned r4 and r5 need to meet the following:
# if r3 == 0: r4 = r5 = 0
# NEED to fix sign of r4 and r5 as below:
# r5 has the same sign as r2
# r4 is positive when r2 and r3 have the same signs, otherwise negative. 

Move(r12,r2) #p12 = p2
Move(r13,r3) #p13 = p3

#if p3 == 0:
# goto >endif if p3 != 0
Addi(r10, pc, ?else)
Movex(pc, r10, r3)
  Set(r4,0)
  Set(r5,0)
  # goto >endif
  Set(r0, ?endif - 1)
  Add(pc, pc, r0) # rel to here

#>else:
  # abs r2, r3
  # if p2 < 0: 
  # goto >endif1 if p2 >= 0
  Addi(r10, pc, ?endif1)
  Movep(pc, r10, r2)
    Set(r0,0) #p2 = -p2
    Sub(r2, r0, r2)
  #>endif1
  # goto >endif2 if p3 >= 0
  Addi(r10, pc, ?endif2)
  Movep(pc, r10, r3)
    Set(r0,0) #p3 = -p3
    Sub(r3, r0, r3)
  #>endif2
  
  # original div
  Set(r4,0) #p4 = 0 #<else
  Move(r5, r2) #p5 = p2
  #>while p5 >= p3:
  # goto >endwhile if p5 < p3
  Addi(r10, pc, ?endwhile) #<while
  Sub(r9, r5, r3)
  Moven(pc, r10, r9)
    Addi(r4,r4,1) #p4 = p4 + 1
    Sub(r5,r5,r3) #p5 = p5 - p3
    # goto >while
    Subi(pc,pc, ?while)
  #>endwhile
  
  # fix sign
  # if p12 < 0:
  # goto >endif3 if p12 >= 0
  Addi(r10, pc, ?endif3)
  Movep(pc, r10, r12)
    Set(r0,0) 
    Sub(r5, r0, r5)
    Sub(r4, r0, r4)
  #>endif3
  # if p13 < 0
  # goto >endif4 if p13 >= 0
  Addi(r10, pc, ?endif4)
  Movep(pc, r10, r13)
    Set(r0,0)
    Sub(r4, r0, r4)
  #>endif4
#>endif
Move(r4,r4)
Move(r5, r5)
"""

mtQ4 = """
# r2, r3 are inputs
# r6, r7 are outputs

# p6 = 6
# p7 = 7
# if (p2 >= 0) and (p3 > p2):
#    p6 = p2
#    p7 = -(p2 + p3)

Set(r6, 6)
Set(r7, 7)

# if (r2 >= 0) and (r3 > r2):
# goto >endif if r2 < 0
Addi(r10, pc, ?endif)
Moven(pc, r10, r2)
# goto >endif if r3 < r2
Addi(r10, pc, ?endif)
Sub(r9, r3, r2)
Moven(pc, r10, r9)
  # thenpart
  Move(r6, r2)
  Add(r7, r2, r3)
  Set(r0, 0)
  Sub(r7, r0, r7)
#>endif

"""

mtQ5 = """
# r2, r3 are inputs
# r6, r7 are outputs

# p6 = 6
# p7 = 7
# if (p2 >= 0) or (p3 > p2):
#    p6 = p2
#    p7 = -(p2 + p3)

Set(r6, 6)
Set(r7, 7)

# if (r2 >= 0) and (r3 > r2):
# goto >thenpart if c1
Addi(r10, pc, ?thenpart)
Movep(pc, r10, r2)
# goto >endif if r3 < r2
Addi(r10, pc, ?endif)
Sub(r9, r3, r2)
Moven(pc, r10, r9)
  #>thenpart
  Move(r6, r2)
  Add(r7, r2, r3)
  Set(r0, 0)
  Sub(r7, r0, r7)
#>endif

"""
