# function call

from bcpu import *

prog = """
# start at >main
Set(r13, ?main - 1)
Add(pc, pc, r13)

#>rotateleft(pv1) -> rv1:
# pop pv1 as r9
Load(r9, st)
Subi(st, st, 1)
# do .... rotateleft
    Set(r0, 0)
    Set(r1, 1)
    Moven(r0, r1, r9)   
    Add(r9, r9, r9)
    Or(r9, r9, r0)
# return rv1
# pop return address
Load(r13, st)
Subi(st, st, 1)
# push rv1
Addi(st, st, 1)
Store(st, r9)
# return
Move(pc, r13)
#>endrotateleft

#>main() # routine
Set(r2, 0b1111_0000)
Seth(r2, 0b1111_0000)
# save r2 by push
Addi(st, st, 1)
Store(st, r2)

# call rotateleft to get it done
# push return address
Addi(r13, pc, ?returnaddress)
Addi(st, st, 1)
Store(st, r13)
# push pv1
Addi(st, st, 1)
Store(st, r2) # r2 as pv1
# call
Set(r13, ?rotateleft + 1)
Sub(pc, pc, 13)
#>returnaddress
# pop rv1
Load(r3, st) # rv1 as r3
Subi(st, st, 1)
#

# restore r2 by doing a pop
Load(r2, st)
Subi(st, st, 1)

Move(r2, r2)
Move(r3, r3)
#>endmain
"""

load(prog)
run()
printb(R[2])
printb(R[3])
