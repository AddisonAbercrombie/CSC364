# if-then-else
from bcpu import *

p1 = 1 # testing
if p1 == 0:
    p2 = 2
    p3 = 3
else:
    p2 = 0
    p3 = 0

print(p1, p2, p3)

# if-then-else
# goto >else if not
    # thenpart
    # ...
    # goto >endif
# >else:
    # elsepart
    # ...
# >endif

ifthenelse1 = """
Set(r1, 0)

# if-then-else (r1 == 0 ?)
# goto >endif if not
# r10 is line of endif
Addi(r10, pc, 5) # <---- PC
Movex(pc, r10, r1) # goto >else if not
    # thenpart
    Set(r2, 2)
    Set(r3, 3)
    Addi(pc, pc, 3) # goto >endif
# >else:
    # elsepart
    Set(r2, 0)
    Set(r3, 0)
# >endif
"""

load(ifthenelse1)
printm()

run()
printr()
