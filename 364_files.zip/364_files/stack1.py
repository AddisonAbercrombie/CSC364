from bcpu import *

# push 20 into stack
Set(r2, 20)
# push
Addi(st, st, 1) # stack top: st
Store(st, r2)

# push 30 into stack
Set(r2, 30)
# push
Addi(st, st, 1) 
Store(st, r2)

# pop
Load(r3, st)
Subi(st, st, 1)

# push 40 into stack
Set(r2, 40)
Addi(st, st, 1)
Store(st, r2)
Move(r3, r3)
# print
printd(0, 10)
