# if-then
from bcpu import *

p2 = p3 = 0
p1 = 1
if p1 == 0:
    p2 = 2
    p3 = 3
# endif

print(p1, p2 ,p3)

# if-then
# goto >endif if not
    # thenpart
    # ...
# >endif

ifthen1 = """
Set(r2, 0)
Set(r3, 0)
Set(r1, 0)

# if-then
# goto >endif if not
# r10 is line of endif
Addi(r10, pc, 4)  # <------ PC
Movex(pc, r10, r1) # goto >endif if not
    # thenpart
    Set(r2, 2)
    Set(r3, 3)
# >endif
"""

load(ifthen1)
printm()

run()
printr()
