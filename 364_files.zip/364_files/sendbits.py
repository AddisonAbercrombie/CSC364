# send bits to storage
from bcpu import *

# testing send r3
Set(r3, 200)
Seth(r3, 0b11010011)

# send one bit at a time to data storage
Set(r0, 0)
Set(r1, 1)
Set(r10, 0) # index of data storage
# 15 bit
Movep(r2, r0, r3)
Moven(r2, r1, r3)
Store(r10, r2)
# next bit
Add(r3, r3, r3) # shift right
Addi(r10, r10, 1) # index counter
Movep(r2, r0, r3)
Moven(r2, r1, r3)
Store(r10, r2)
# next bit
Add(r3, r3, r3)
Addi(r10, r10, 1)
Movep(r2, r0, r3)
Moven(r2, r1, r3)
Store(r10, r2)

printd()
