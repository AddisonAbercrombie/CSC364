# div test
from bcpu import *

from divfnlib import *

divmain = """
#>main()

Set(r2, 20)
Set(r3, 3)

# call divfn
# push return addr
Addi(r13, pc, ?returnaddr)
Addi(st, st, 1)
Store(st, r13)
# call
Set(r13, ?divfn % 256)
Seth(r13, ?divfn // 256)
Move(pc, r13)
#>returnaddr
# print
Move(r4, r4)
Move(r5, r5)

#>endmain
"""

load(divmain)
run()
