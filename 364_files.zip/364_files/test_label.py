# test label
from bcpu import *

p4 = 0
p2 = 15

while p2 > 0:
    p4 = p4 + p2
    p2 = p2 - 1

print(p4)

test_label = """

Set(r4, 0) # p4 = 0
Set(r2, 15) # p2 = 15

#>while p2 > 0:
# goto >endwhile if not p2 <= 0
Set(r0, 0)
Sub(r9, r0, r2)
Set(r10, ?endwhile - 1) # offset to here
Add(r10, pc, r10) # relative to here
Movep(pc, r10, r9)
    Add(r4, r4, r2) # p4 = p4 + p2
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Move(r5, r4)
    Subi(r2, r2, 1) # p2 = p2 - 1
    # goto >while
    Set(r10, ?while + 1)
    Sub(pc, pc, r10) # relative to here
#>endwhile

# print(p4)
Move(r4, r4)
"""
load(test_label)
run()
