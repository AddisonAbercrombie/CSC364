from bcpu import *

p2 = 2 # counter
p3 = 3

# fix sign
if p2 < 0:
    p2 = -p2
    p3 = -p3

# multiply
p4 = 0
while p2 > 0:
    p4 = p4 + p3
    p2 = p2 - 1

print(p4)


# asm

mul = """


Set(r0, 0)
# if p2 < 0
# goto >endif if p2 >= 0
Addi(r10, pc, 4) # >endif
Movep(pc, r10, r2)
    Sub(r2, r0, r2)
    Sub(r3, r0, r3)
# >endif

Set(r4, 0) # p4 = 0
# >while p2 > 0
# goto >endwhile if p2 <= 0
Addi(r10, pc, 6) # >endwhile
Sub(r9, r0, r2)
Movep(pc, r10, r9)
    Add(r4, r4, r3)
    Subi(r2, r2, 1)
    Subi(pc, pc, 4)
# >endwhile

Move(r4, r4) # print(p4)
"""

load(mul)

# testing
Set(r2, 2)
Set(r3, 3)

printm()

run()

