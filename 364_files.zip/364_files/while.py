# while loop
from bcpu import *

i = 0
s = 0
while i<10:
    s = s + i
    i = i + 1
print(s)


# init variable
# ...
# >while
# goto >endwhile if not
    # whilepart
    # ...
    # update variable
    # ...
    # goto >while
# >endwhile

whileloop = """
Set(r2, 0) # i
Set(r3, 0) # s sum

Subi(r9, r2, 10) # test condition
Addi(r10, pc, 5) # >endwhile
Movep(pc, r10, r9)
    # whilepart
    Add(r3, r3, r2)
    Addi(r2, r2, 1)
    Subi(pc, pc, 5)
# >endwhile

Move(r3, r3) # print
"""

load(whileloop)
printm()

run()
    

