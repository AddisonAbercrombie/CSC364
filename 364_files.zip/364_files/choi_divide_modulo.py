from bcpu import *

# r4 = r2 // r3 -> integer division
# r5 = r2 % r3 -> modulo
# r2, r3 are positive numbers

##if p3 == 0:
##    p4 = -1
##    p5 = -1

# testing data

p2 = 3 # Numerator
p3 = 2 # Denominator

if p3 == 0:
    p4 = -1
    p5 = -1
else:
    p4 = 0 # Quotient
    p5 = p2 # Remainder
    while p5 >= p3:
        p4 += 1
        p5 = p5 - p3
        
print(p2, p3, p4, p5)


divide_modulo = """
# testing data

Set(r2, 6) # p2 = 3 # Numerator
Set(r3, 2) # p3 = 2 # Denominator

# if p3 == 0:
# goto >else if p3 != 0
Addi(r10, pc, 7) # >else
Movex(pc, r10, r3) # p3 != 0
    Set(r0, 0)
    Set(r1, 1)
    Sub(r4, r0, r1) # p4 = -1
    Move(r5, r4) # p5 = -1
    # goto >endif
    Addi(pc, pc, 9)
# >else:
    Set(r4, 0) # p4 = 0 # Quotient
    Move(r5, r2) # p5 = p2 # Remainder
    # >while p5 >= p3:
    # goto >endwhile if p5 < p3
    Sub(r9, r5, r3)
    Addi(r10, pc, 5) # >endwhile
    Moven(pc, r10, r9)
        Addi(r4, r4, 1) # p4 += 1
        Sub(r5, r5, r3) # p5 = p5 - p3
        # goto >while
        Subi(pc, pc, 5)
    # >endwhile
# >endif      
# print(p2, p3, p4, p5)
Move(r4, r4)
Move(r5, r5)

"""

load(divide_modulo)
run()
