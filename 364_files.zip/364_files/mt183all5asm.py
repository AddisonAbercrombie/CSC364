# mt183all5asm.py file

myName = 'Damare, Christopher'
myTechID = '10250397'
myTechEmail = 'ced020@latech.edu'

mtQ1 = """
# r6 = r5 - 7 * r3 + 800
# r5, r3 are integer inputs that will be passed to this routine
# r6 is the output to be returned

Set(r1, 0) # p1 = 0
Set(r2, 0) # p2 = 0
Set(r7, 0b00100000)
Seth(r7, 0b11)

# > while(p1 != p3):
# goto >endwhile if not p1 != p3
Sub(r9, r1, r3)
Addi(r10, pc, 6)
Movez(pc, r10, r9)
    Addi(r6, r2, 7) # p6 = 7 + p2
    Move(r2, r6) # p2 = p6
    Addi(r1, r1, 1) # p1 += 1
    Subi(pc, pc, 6)
Sub(r6, r5, r6) # p6 = p5 - p6
Add(r6, r6, r7) # p6 = p6 + 800

Move(r6, r6)
"""

mtQ2 = """
# r6 = rotate_right(r2)
# r2 is an integer input
# r6 is the output that is bitwise rotate right once of r2
# HINT: rotate left 15 times results in rotate right once


"""

mtQ3 = """
# r4 = abs(r2) // abs(r3)
# r5 = abs(r2) % abs(r3)
# r2, r3 are integer inputs that can be positive, negative, or zero. 
# r4, r5 are outputs where the returned r4 and r5 need to meet the following:
# if r3 == 0: r4 = r5 = 0
# NEED to fix sign of r4 and r5 as below:
# r5 has the same sign as r2
# r4 is positive when r2 and r3 have the same signs, otherwise negative. 


"""

mtQ4 = """
# r2, r3 are inputs
# r6, r7 are outputs

# p6 = 6
# p7 = 7
# if (p2 >= 0) and (p3 > p2):
#    p6 = p2
#    p7 = -(p2 + p3)

# translate the above code to ASM keeping the structure (only one thenpart)

Set(r0, 0)
Sub(r4, r0, r2)


Addi(r10, pc, 6)
Movep(pc, r10, r4)
Moven(pc, r10, r3)
    Move(r6, r2)
    Add(r7, r2, r3)
    Sub(r7, r0, r7)


"""

mtQ5 = """
# r2, r3 are inputs
# r6, r7 are outputs

# p6 = 6
# p7 = 7
# if (p2 >= 0) or (p3 > p2):
#    p6 = p2
#    p7 = -(p2 + p3)

# translate the above code to ASM keeping the structure (only one thenpart)


"""
