# bcpu startup
from bcpu import *
