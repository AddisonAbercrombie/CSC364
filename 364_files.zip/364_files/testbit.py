# bcpu startup
from bcpu import *

# Test bit number 4 of r3, if that is 1, set r2 = 1
# else set r2 = 0.

# testing
Set(r3, 0b00111100)

# code
Set(r0, 0)
Set(r1, 1)
Set(r4, 0b10000)
And(r5, r3, r4)
Movex(r2, r1, r5)

print("r2 =",R[r2])


 
