# meh
from bcpu import *

# movez(Rd, Ra, Rb)
# Rd = Ra if Rb == 0 else Rd

# movex(Rd, Ra, Rb)
# Rd = Ra if Rb != 0 else Rd

# movep(Rd, Ra, Rb)
# Rd = Ra if Rb >= 0 else Rd

# moven(Rd, Ra, Rb)
# Rd = Ra if Rb < 0 else Rd

#testing
Set(r0, 0)
Set(r2, 5)
Sub(r2, r0, r2)
Set(r3, 5)
Sub(r3, r0, r3)


# comparing two numbers r2, r3
# six different outcomes


# r2 == r3
# r4 = r2 - r3
# Movez(?, ?, r4)

Sub(r4, r2, r3)
Set(r10, 0)
Set(r1, 1)
Movez(r10, r1, r4)

printr()

# r2 != r3
# r4 = r2 - r3
# Movex(?, ?, r4)

Sub(r4, r2, r3)
Set(r10, 0)
Set(r1, 1)
Movex(r10, r1, r4)

printr()

# r2 >= r3
# r4 = r2 - r3
# Movep(?, ?, r4)

Sub(r4, r2, r3)
Set(r10, 0)
Set(r1, 1)
Movep(r10, r1, r4)

printr()

# r2 <= r3
# r4 = r3 - r2
# Movep(?, ?, r4)

Sub(r4, r3, r2)
Set(r10, 0)
Set(r1, 1)
Movep(r10, r1, r4)

printr()

# r2 > r3
# r4 = r3 - r2
# Moven(?, ?, r4)

Sub(r4, r3, r2)
Set(r10, 0)
Set(r1, 1)
Moven(r10, r1, r4)

printr()

# r2 < r3
# r4= r2 - r3
# Moven(?, ?, r4)

Sub(r4, r2, r3)
Set(r10, 0)
Set(r1, 1)
Moven(r10, r1, r4)

printr()
